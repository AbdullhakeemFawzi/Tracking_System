<?php 

header('Location:dashboard/index.php');
exit();