<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// $mysqli = new mysqli("localhost", "root", "", "car_system");
$mysqli = new mysqli("localhost", "u222784783_ahmed_car", "Qweff112233+", "u222784783_car_system");


// التحقق من وجود car_id
if (!isset($_GET['car_id']) || empty($_GET['car_id'])) {
    header('Location: admin_dashboard.php');
    exit;
}

$car_id = intval($_GET['car_id']);

// جلب معلومات السيارة
$car_stmt = $mysqli->prepare("SELECT cars.*, users.name as user_name FROM cars JOIN users ON cars.user_id = users.id WHERE cars.id = ?");
$car_stmt->bind_param("i", $car_id);
$car_stmt->execute();
$car_result = $car_stmt->get_result();
$car = $car_result->fetch_assoc();

if (!$car) {
    header('Location: admin_dashboard.php');
    exit;
}
$car_stmt->close();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سجل مواقع السيارة - لوحة تحكم المدير</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCrRFrgnU5kENw45gvHaTJQL5yXGUw1zoc"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin_dashboard.php">لوحة تحكم المدير</a>
    <div class="d-flex">
      <a href="logout.php" class="btn btn-outline-light">تسجيل الخروج</a>
    </div>
  </div>
</nav>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>سجل مواقع السيارة</h1>
        <a href="admin_dashboard.php" class="btn btn-secondary">العودة للوحة التحكم</a>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">معلومات السيارة</h5>
            <div class="row">
                <div class="col-md-4">
                    <strong>اسم السيارة:</strong> <?= htmlspecialchars($car['car_name']) ?>
                </div>
                <div class="col-md-4">
                    <strong>معرف السيارة:</strong> <?= htmlspecialchars($car['car_identifier']) ?>
                </div>
                <div class="col-md-4">
                    <strong>المالك:</strong> <?= htmlspecialchars($car['user_name']) ?>
                </div>
            </div>
        </div>
    </div>

    <form class="row g-3 mb-4" method="GET">
        <input type="hidden" name="car_id" value="<?= $car_id ?>">
        <div class="col-md-6">
            <label for="date" class="form-label">تاريخ (اختياري)</label>
            <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($_GET['date'] ?? ''); ?>">
        </div>
        <div class="col-md-6">
            <label for="limit" class="form-label">عدد النقاط</label>
            <select class="form-select" id="limit" name="limit">
                <option value="50" <?= ($_GET['limit'] ?? '50') == '50' ? 'selected' : '' ?>>50 نقطة</option>
                <option value="100" <?= ($_GET['limit'] ?? '50') == '100' ? 'selected' : '' ?>>100 نقطة</option>
                <option value="200" <?= ($_GET['limit'] ?? '50') == '200' ? 'selected' : '' ?>>200 نقطة</option>
                <option value="500" <?= ($_GET['limit'] ?? '50') == '500' ? 'selected' : '' ?>>500 نقطة</option>
            </select>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">بحث</button>
            <button type="button" class="btn btn-success" onclick="exportCSV()">تصدير البيانات</button>
        </div>
    </form>

    <div id="map" style="height: 400px; width: 100%; margin-bottom: 20px;"></div>

    <h3>سجل المواقع</h3>
    <table class="table table-bordered table-striped" id="historyTable">
        <thead>
            <tr>
                <th>التاريخ والوقت</th>
                <th>خط العرض</th>
                <th>خط الطول</th>
                <th>رابط الخريطة</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $locations = [];
        $date_filter = isset($_GET['date']) && $_GET['date'] != '' ? $_GET['date'] : null;
        $limit = intval($_GET['limit'] ?? 50);
        
        $query = "SELECT latitude, longitude, timestamp FROM locations WHERE car_id = ?";
        $params = [$car_id];
        $types = "i";
        
        if ($date_filter) {
            $query .= " AND DATE(timestamp) = ?";
            $params[] = $date_filter;
            $types .= "s";
        }
        
        $query .= " ORDER BY timestamp DESC LIMIT ?";
        $params[] = $limit;
        $types .= "i";
        
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $locations[] = $row;
            $google_maps_url = "https://maps.google.com/maps?q=" . $row['latitude'] . "," . $row['longitude'];
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['timestamp']) . "</td>";
            echo "<td>" . htmlspecialchars($row['latitude']) . "</td>";
            echo "<td>" . htmlspecialchars($row['longitude']) . "</td>";
            echo "<td><a href='$google_maps_url' target='_blank' class='btn btn-sm btn-outline-primary'>عرض على الخريطة</a></td>";
            echo "</tr>";
        }
        $stmt->close();
        
        // عكس المصفوفة لعرض المسار بالترتيب الصحيح على الخريطة
        $locations_for_map = array_reverse($locations);
        $latest = count($locations) > 0 ? $locations[0] : null;
        ?>
        </tbody>
    </table>
    
    <?php if (empty($locations)): ?>
        <div class="alert alert-info">
            لا توجد بيانات مواقع لهذه السيارة في التاريخ المحدد.
        </div>
    <?php endif; ?>
</div>

<script>
function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 15.3694, lng: 44.1910},
        zoom: 7
    });
    
    var route = [];
    <?php if (!empty($locations_for_map)) {
        foreach ($locations_for_map as $loc) {
            echo "route.push({lat: " . floatval($loc['latitude']) . ", lng: " . floatval($loc['longitude']) . "});\n";
        }
    }
    if (isset($latest) && $latest) { ?>
        var marker = new google.maps.Marker({
            position: {lat: <?php echo $latest['latitude']; ?>, lng: <?php echo $latest['longitude']; ?>},
            map: map,
            title: 'آخر موقع للسيارة',
            icon: {
                url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
            }
        });
        map.setCenter(marker.getPosition());
        map.setZoom(15);
    <?php }
    ?>
    
    if (route.length > 1) {
        var polyline = new google.maps.Polyline({
            path: route,
            geodesic: true,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 3
        });
        polyline.setMap(map);
        
        // إضافة مؤشرات للنقاط المهمة
        if (route.length > 0) {
            var startMarker = new google.maps.Marker({
                position: route[0],
                map: map,
                title: 'نقطة البداية',
                icon: {
                    url: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
                }
            });
        }
    }
}

google.maps.event.addDomListener(window, 'load', initMap);

function exportCSV() {
    var table = document.getElementById('historyTable');
    var rows = Array.from(table.querySelectorAll('tr'));
    var csv = [];
    
    for (var i = 0; i < rows.length; i++) {
        var cols = rows[i].querySelectorAll('th,td');
        var row = [];
        for (var j = 0; j < cols.length - 1; j++) { // استبعاد عمود رابط الخريطة
            row.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
        }
        csv.push(row.join(','));
    }
    
    var csvFile = new Blob([csv.join('\n')], {type: 'text/csv'});
    var downloadLink = document.createElement('a');
    downloadLink.download = 'car_locations_<?= $car['car_identifier'] ?>_<?= date('Y-m-d') ?>.csv';
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
</script>
</body>
</html> 