<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم العميل</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCrRFrgnU5kENw45gvHaTJQL5yXGUw1zoc"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">لوحة تحكم العميل</a>
    <div class="d-flex">
      <a href="logout.php" class="btn btn-outline-light">تسجيل الخروج</a>
    </div>
  </div>
</nav>
<div class="container mt-5">
    <h1>مرحباً بك!</h1>
    <form class="row g-3 mb-4" method="GET" action="customer_dashboard.php">
        <div class="col-md-6">
            <label for="car_id" class="form-label">اختر سيارتك</label>
            <select class="form-select" id="car_id" name="car_id" required>
                <option value="">اختر السيارة...</option>
                <?php
                // جلب السيارات المرتبطة بالمستخدم
                $mysqli = new mysqli("localhost", "u222784783_ahmed_car", "Qweff112233+", "u222784783_car_system");
                $user_id = $_SESSION['user_id'];
                $result = $mysqli->query("SELECT id, car_name FROM cars WHERE user_id = $user_id");
                while ($row = $result->fetch_assoc()) {
                    $selected = (isset($_GET['car_id']) && $_GET['car_id'] == $row['id']) ? 'selected' : '';
                    echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['car_name']) . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-6">
            <label for="date" class="form-label">تاريخ (اختياري)</label>
            <input type="date" class="form-control" id="date" name="date" value="<?php echo htmlspecialchars($_GET['date'] ?? ''); ?>">
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-success">بحث</button>
            <?php if (isset($_GET['car_id']) && $_GET['car_id'] != ''): ?>
                <button type="button" class="btn btn-secondary" onclick="exportCSV()">تصدير سجل المواقع</button>
            <?php endif; ?>
        </div>
    </form>
    <div id="map" style="height: 400px; width: 100%;"></div>
    <h3 class="mt-4">سجل المواقع</h3>
    <table class="table table-bordered table-striped mb-4" id="historyTable">
        <thead>
            <tr>
                <th>التاريخ والوقت</th>
                <th>خط العرض</th>
                <th>خط الطول</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $locations = [];
        if (isset($_GET['car_id']) && $_GET['car_id'] != '') {
            $car_id = intval($_GET['car_id']);
            $date_filter = isset($_GET['date']) && $_GET['date'] != '' ? $_GET['date'] : null;
            $query = "SELECT latitude, longitude, timestamp FROM locations WHERE car_id = $car_id";
            if ($date_filter) {
                $query .= " AND DATE(timestamp) = '" . $mysqli->real_escape_string($date_filter) . "'";
            }
            $query .= " ORDER BY timestamp ASC LIMIT 100";
            $result = $mysqli->query($query);
            while ($row = $result->fetch_assoc()) {
                $locations[] = $row;
                echo "<tr><td>" . htmlspecialchars($row['timestamp']) . "</td><td>" . htmlspecialchars($row['latitude']) . "</td><td>" . htmlspecialchars($row['longitude']) . "</td></tr>";
            }
            $latest = count($locations) > 0 ? $locations[count($locations)-1] : null;
        } else {
            $latest = null;
        }
        ?>
        </tbody>
    </table>
</div>
<script>
function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 15.3694, lng: 44.1910},
        zoom: 7
    });
    var route = [];
    <?php if (!empty($locations)) {
        foreach ($locations as $loc) {
            echo "route.push({lat: " . floatval($loc['latitude']) . ", lng: " . floatval($loc['longitude']) . "});\n";
        }
    }
    if (isset($latest) && $latest) { ?>
        var marker = new google.maps.Marker({
            position: {lat: <?php echo $latest['latitude']; ?>, lng: <?php echo $latest['longitude']; ?>},
            map: map,
            title: 'آخر موقع للسيارة'
        });
        map.setCenter(marker.getPosition());
        map.setZoom(15);
    <?php }
    ?>
    if (route.length > 1) {
        var polyline = new google.maps.Polyline({
            path: route,
            geodesic: true,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 3
        });
        polyline.setMap(map);
    }
}
google.maps.event.addDomListener(window, 'load', initMap);

function exportCSV() {
    var table = document.getElementById('historyTable');
    var rows = Array.from(table.querySelectorAll('tr'));
    var csv = [];
    for (var i = 0; i < rows.length; i++) {
        var cols = rows[i].querySelectorAll('th,td');
        var row = [];
        for (var j = 0; j < cols.length; j++) {
            row.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
        }
        csv.push(row.join(','));
    }
    var csvFile = new Blob([csv.join('\n')], {type: 'text/csv'});
    var downloadLink = document.createElement('a');
    downloadLink.download = 'location_history.csv';
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
</script>
</body>
</html> 