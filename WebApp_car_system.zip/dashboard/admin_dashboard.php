<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}
// $mysqli = new mysqli("localhost", "root", "", "car_system");
$mysqli = new mysqli("localhost", "u222784783_ahmed_car", "Qweff112233+", "u222784783_car_system");

$error_message = '';
$success_message = '';

// إضافة مستخدم جديد
if (isset($_POST['add_user'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    
    // التحقق من عدم وجود البريد الإلكتروني مسبقاً
    $check_stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_stmt->store_result();
    if ($check_stmt->num_rows > 0) {
        $error_message = 'البريد الإلكتروني موجود مسبقاً!';
    } else {
        $stmt = $mysqli->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        if ($stmt->execute()) {
            $success_message = 'تم إضافة المستخدم بنجاح!';
        } else {
            $error_message = 'خطأ في إضافة المستخدم!';
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// تعديل مستخدم
if (isset($_POST['edit_user'])) {
    $user_id = intval($_POST['user_id']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    
    // التحقق من عدم وجود البريد الإلكتروني مسبقاً (باستثناء المستخدم الحالي)
    $check_stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $check_stmt->bind_param("si", $email, $user_id);
    $check_stmt->execute();
    $check_stmt->store_result();
    if ($check_stmt->num_rows > 0) {
        $error_message = 'البريد الإلكتروني موجود مسبقاً!';
    } else {
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, password=?, role=? WHERE id=?");
            $stmt->bind_param("ssssi", $name, $email, $password, $role, $user_id);
        } else {
            $stmt = $mysqli->prepare("UPDATE users SET name=?, email=?, role=? WHERE id=?");
            $stmt->bind_param("sssi", $name, $email, $role, $user_id);
        }
        if ($stmt->execute()) {
            $success_message = 'تم تحديث بيانات المستخدم بنجاح!';
        } else {
            $error_message = 'خطأ في تحديث بيانات المستخدم!';
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// حذف مستخدم
if (isset($_POST['delete_user'])) {
    $user_id = intval($_POST['user_id']);
    if ($mysqli->query("DELETE FROM users WHERE id = $user_id")) {
        $success_message = 'تم حذف المستخدم بنجاح!';
    } else {
        $error_message = 'خطأ في حذف المستخدم!';
    }
}

// إضافة سيارة جديدة
if (isset($_POST['add_car'])) {
    $car_name = trim($_POST['car_name']);
    $car_identifier = trim($_POST['car_identifier']);
    $user_id = intval($_POST['user_id']);
    
    // التحقق من عدم وجود معرف السيارة مسبقاً
    $check_stmt = $mysqli->prepare("SELECT id FROM cars WHERE car_identifier = ?");
    $check_stmt->bind_param("s", $car_identifier);
    $check_stmt->execute();
    $check_stmt->store_result();
    if ($check_stmt->num_rows > 0) {
        $error_message = 'معرف السيارة موجود مسبقاً!';
    } else {
        $stmt = $mysqli->prepare("INSERT INTO cars (car_name, car_identifier, user_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $car_name, $car_identifier, $user_id);
        if ($stmt->execute()) {
            $success_message = 'تم إضافة السيارة بنجاح!';
        } else {
            $error_message = 'خطأ في إضافة السيارة!';
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// تعديل سيارة
if (isset($_POST['edit_car'])) {
    $car_id = intval($_POST['car_id']);
    $car_name = trim($_POST['car_name']);
    $car_identifier = trim($_POST['car_identifier']);
    $user_id = intval($_POST['user_id']);
    
    // التحقق من عدم وجود معرف السيارة مسبقاً (باستثناء السيارة الحالية)
    $check_stmt = $mysqli->prepare("SELECT id FROM cars WHERE car_identifier = ? AND id != ?");
    $check_stmt->bind_param("si", $car_identifier, $car_id);
    $check_stmt->execute();
    $check_stmt->store_result();
    if ($check_stmt->num_rows > 0) {
        $error_message = 'معرف السيارة موجود مسبقاً!';
    } else {
        $stmt = $mysqli->prepare("UPDATE cars SET car_name=?, car_identifier=?, user_id=? WHERE id=?");
        $stmt->bind_param("ssii", $car_name, $car_identifier, $user_id, $car_id);
        if ($stmt->execute()) {
            $success_message = 'تم تحديث بيانات السيارة بنجاح!';
        } else {
            $error_message = 'خطأ في تحديث بيانات السيارة!';
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// حذف سيارة
if (isset($_POST['delete_car'])) {
    $car_id = intval($_POST['car_id']);
    if ($mysqli->query("DELETE FROM cars WHERE id = $car_id")) {
        $success_message = 'تم حذف السيارة بنجاح!';
    } else {
        $error_message = 'خطأ في حذف السيارة!';
    }
}

// جلب المستخدمين
$users = $mysqli->query("SELECT * FROM users");
// جلب السيارات مع اسم المستخدم
$cars = $mysqli->query("SELECT cars.*, users.name as user_name FROM cars JOIN users ON cars.user_id = users.id");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المدير</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">لوحة تحكم المدير</a>
    <div class="d-flex">
      <a href="logout.php" class="btn btn-outline-light">تسجيل الخروج</a>
    </div>
  </div>
</nav>
<div class="container mt-5">
    <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $error_message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $success_message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <h1>مرحباً بك، مدير النظام!</h1>
    <p>هنا يمكنك إدارة المستخدمين والسيارات وعرض جميع بيانات التتبع.</p>
    <div class="row">
        <div class="col-md-6">
            <h3>إدارة المستخدمين</h3>
            <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#addUserModal">إضافة مستخدم</button>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>البريد الإلكتروني</th>
                        <th>الدور</th>
                        <th>إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $users->data_seek(0); while($user = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['name']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= $user['role'] === 'admin' ? 'مدير' : 'عميل' ?></td>
                        <td>
                            <!-- تعديل -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $user['id'] ?>">تعديل</button>
                            <!-- حذف -->
                             <?php if($_SESSION['user_id'] != $user['id']){ ?>
                            <form method="POST" style="display:inline-block" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                <button type="submit" name="delete_user" class="btn btn-danger btn-sm">حذف</button>
                            </form>
                            <?php } ?>
                        </td>
                    </tr>
                    <!-- Modal تعديل مستخدم -->
                    <div class="modal fade" id="editUserModal<?= $user['id'] ?>" tabindex="-1" aria-labelledby="editUserModalLabel<?= $user['id'] ?>" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form method="POST">
                            <div class="modal-header">
                              <h5 class="modal-title" id="editUserModalLabel<?= $user['id'] ?>">تعديل بيانات المستخدم</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                            </div>
                            <div class="modal-body">
                              <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                              <div class="mb-3">
                                <label class="form-label">الاسم</label>
                                <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">البريد الإلكتروني</label>
                                <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">كلمة المرور الجديدة (اتركها فارغة إذا لا تريد التغيير)</label>
                                <input type="password" class="form-control" name="password" minlength="6">
                              </div>
                              <div class="mb-3">
                                <label class="form-label">الدور</label>
                                <select class="form-select" name="role" required>
                                  <option value="customer" <?= $user['role']==='customer'?'selected':'' ?>>عميل</option>
                                  <option value="admin" <?= $user['role']==='admin'?'selected':'' ?>>مدير</option>
                                </select>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                              <button type="submit" name="edit_user" class="btn btn-primary">حفظ التعديلات</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <h3>إدارة السيارات</h3>
            <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#addCarModal">إضافة سيارة</button>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>اسم السيارة</th>
                        <th>معرف السيارة</th>
                        <th>المستخدم</th>
                        <th>إجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $cars->data_seek(0); while($car = $cars->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($car['car_name']) ?></td>
                        <td><?= htmlspecialchars($car['car_identifier']) ?></td>
                        <td><?= htmlspecialchars($car['user_name']) ?></td>
                        <td>
                            <!-- عرض المواقع -->
                            <a href="admin_car_locations.php?car_id=<?= $car['id'] ?>" class="btn btn-info btn-sm">عرض المواقع</a>
                            <!-- تعديل -->
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editCarModal<?= $car['id'] ?>">تعديل</button>
                            <!-- حذف -->
                            <form method="POST" style="display:inline-block" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                <input type="hidden" name="car_id" value="<?= $car['id'] ?>">
                                <button type="submit" name="delete_car" class="btn btn-danger btn-sm">حذف</button>
                            </form>
                        </td>
                    </tr>
                    <!-- Modal تعديل سيارة -->
                    <div class="modal fade" id="editCarModal<?= $car['id'] ?>" tabindex="-1" aria-labelledby="editCarModalLabel<?= $car['id'] ?>" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form method="POST">
                            <div class="modal-header">
                              <h5 class="modal-title" id="editCarModalLabel<?= $car['id'] ?>">تعديل بيانات السيارة</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                            </div>
                            <div class="modal-body">
                              <input type="hidden" name="car_id" value="<?= $car['id'] ?>">
                              <div class="mb-3">
                                <label class="form-label">اسم السيارة</label>
                                <input type="text" class="form-control" name="car_name" value="<?= htmlspecialchars($car['car_name']) ?>" required>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">معرف السيارة (يجب أن يكون فريداً)</label>
                                <input type="text" class="form-control" name="car_identifier" value="<?= htmlspecialchars($car['car_identifier']) ?>" required>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">المستخدم</label>
                                <select class="form-select" name="user_id" required>
                                  <?php
                                  $users2 = $mysqli->query("SELECT id, name FROM users WHERE role = 'customer'");
                                  while($u = $users2->fetch_assoc()): ?>
                                    <option value="<?= $u['id'] ?>" <?= $car['user_id']==$u['id']?'selected':'' ?>><?= htmlspecialchars($u['name']) ?></option>
                                  <?php endwhile; ?>
                                </select>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                              <button type="submit" name="edit_car" class="btn btn-primary">حفظ التعديلات</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Modal إضافة مستخدم -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="addUserModalLabel">إضافة مستخدم جديد</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">الاسم</label>
            <input type="text" class="form-control" name="name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">البريد الإلكتروني</label>
            <input type="email" class="form-control" name="email" required>
          </div>
          <div class="mb-3">
            <label class="form-label">كلمة المرور</label>
            <input type="password" class="form-control" name="password" required minlength="6">
          </div>
          <div class="mb-3">
            <label class="form-label">الدور</label>
            <select class="form-select" name="role" required>
              <option value="customer">عميل</option>
              <option value="admin">مدير</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
          <button type="submit" name="add_user" class="btn btn-primary">إضافة</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Modal إضافة سيارة -->
<div class="modal fade" id="addCarModal" tabindex="-1" aria-labelledby="addCarModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="addCarModalLabel">إضافة سيارة جديدة</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">اسم السيارة</label>
            <input type="text" class="form-control" name="car_name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">معرف السيارة (يجب أن يكون فريداً)</label>
            <input type="text" class="form-control" name="car_identifier" required>
          </div>
          <div class="mb-3">
            <label class="form-label">المستخدم</label>
            <select class="form-select" name="user_id" required>
              <?php
              $users2 = $mysqli->query("SELECT id, name FROM users WHERE role = 'customer'");
              while($u = $users2->fetch_assoc()): ?>
                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
          <button type="submit" name="add_car" class="btn btn-primary">إضافة</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 