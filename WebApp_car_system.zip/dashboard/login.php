<?php

session_start();
// Database connection
$mysqli = new mysqli("localhost", "u222784783_ahmed_car", "Qweff112233+", "u222784783_car_system");
if ($mysqli->connect_errno) {
    die("<div class='alert alert-danger'>فشل الاتصال بقاعدة البيانات</div>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $error = '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'البريد الإلكتروني غير صحيح.';
    } elseif (strlen($password) < 6) {
        $error = 'يجب أن تكون كلمة المرور 6 أحرف على الأقل.';
    } else {
        $stmt = $mysqli->prepare("SELECT id, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $hash, $role);
            $stmt->fetch();
            if (password_verify($password, $hash)) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['role'] = $role;
                if ($role === 'admin') {
                    header('Location: admin_dashboard.php');
                } else {
                    header('Location: customer_dashboard.php');
                }
                exit;
            } else {
                $error = 'كلمة المرور غير صحيحة.';
            }
        } else {
            $error = 'المستخدم غير موجود.';
        }
        $stmt->close();
    }
    if ($error) {
        echo "<div class='alert alert-danger text-center'>$error</div>";
        echo "<a href='index.php' class='btn btn-secondary mt-2'>العودة إلى تسجيل الدخول</a>";
    }
}
$mysqli->close();
?> 