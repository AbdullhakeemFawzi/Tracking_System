<?php
// Database connection
$mysqli = new mysqli("localhost", "u222784783_ahmed_car", "Qweff112233+", "u222784783_car_system");

if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

// Set your API key here (must match what the ESP32 sends)
$API_KEY = "YemenCars123";

// Get POST data
$car_identifier = $_GET['car_identifier'] ?? '';
$latitude = $_GET['latitude'] ?? '';
$longitude = $_GET['longitude'] ?? '';
$timestamp = $_GET['timestamp'] ?? date('Y-m-d H:i:s');
$api_key = $_GET['api_key'] ?? '';

// Input validation
if ($api_key !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Invalid API key"]);
    exit;
}
if (!$car_identifier || !is_numeric($latitude) || !is_numeric($longitude)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing or invalid parameters"]);
    exit;
}

// Find car_id by car_identifier
$stmt = $mysqli->prepare("SELECT id FROM cars WHERE car_identifier = ?");
$stmt->bind_param("s", $car_identifier);
$stmt->execute();
$stmt->bind_result($car_id);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Car not found"]);
    exit;
}
$stmt->close();

// Insert location
$stmt = $mysqli->prepare("INSERT INTO locations (car_id, latitude, longitude, timestamp) VALUES (?, ?, ?, ?)");
$stmt->bind_param("idds", $car_id, $latitude, $longitude, $timestamp);
if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Failed to insert location"]);
}
$stmt->close();
$mysqli->close();
?> 